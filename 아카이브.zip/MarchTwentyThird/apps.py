from django.apps import AppConfig


class MarchtwentythirdConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MarchTwentyThird'
